import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;

import Administravimas.AdministratoriausVeiksmai;
import Autentifikacija.Prisijungimas;
import Autentifikacija.Registracija;
import DuomenuBaze.DuomenuBaze;

public class Main {
    public static void main(String[] args) {
        boolean runProgram = true;
        while (runProgram) {
            try {
                Connection connection = DuomenuBaze.prisijungti();
                Scanner scanner = new Scanner(System.in);

                while (true) {
                    System.out.println("Pasirinkite veiksmą:");
                    System.out.println("1. Prisijungti");
                    System.out.println("2. Registruotis");
                    System.out.println("3. Administravimas");
                    System.out.println("0. Baigti programą");
                    System.out.print("Įveskite pasirinkimą (0, 1, 2 arba 3): ");

                    int pasirinkimas = scanner.nextInt();
                    scanner.nextLine();

                    switch (pasirinkimas) {
                        case 0:
                            runProgram = false;
                            break;
                        case 1:
                            prisijungti(connection);
                            break;
                        case 2:
                            registruotis(connection);
                            break;
                        case 3:
                            prisijungtiKaipAdministratorius(connection, scanner);
                            break;
                        default:
                            System.out.println("Neteisingas pasirinkimas.");
                    }

                    if (!runProgram) {
                        break;
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (InputMismatchException e) {
                Scanner scanner = new Scanner(System.in);

                System.out.println("Neteisingas pasirinkimas. Prašome įvesti skaičių.");
                scanner.nextLine(); // Išvalyti įvesties srautą
            }
        }

        System.out.println("Programa baigta.");
    }

    private static void prisijungti(Connection connection) {
        Scanner scanner = new Scanner(System.in);

        Prisijungimas prisijungimas = new Prisijungimas(connection, scanner);

        prisijungimas.prisijungti();
    }

    private static void registruotis(Connection connection) {
        Registracija registracija = new Registracija(connection);
        registracija.registruoti();
    }

    private static void prisijungtiKaipAdministratorius(Connection connection, Scanner scanner) {
        System.out.println("Prisijungimas kaip administratorius");
        System.out.print("Vartotojo vardas: ");
        String vardas = scanner.nextLine();
        System.out.print("Slaptažodis: ");
        String slaptazodis = scanner.nextLine();

        try {
            String sql = "SELECT * FROM naudotojai WHERE vardas = ? AND slaptazodis = ? AND role = 'Administratorius'";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, vardas);
            statement.setString(2, slaptazodis);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                System.out.println("Sėkmingas prisijungimas kaip administratorius!");
                administruoti(connection, scanner); // Čia kviečiame metodą, kuris vykdys administratoriaus veiksmus
            } else {
                System.out.println("Neteisingi prisijungimo duomenys arba jūsų vartotojas neturi administratoriaus teisių.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void administruoti(Connection connection, Scanner scanner) {
        AdministratoriausVeiksmai adminVeiksmai = new AdministratoriausVeiksmai(connection, scanner);
        boolean loggedIn = true;
        while (loggedIn) {
            try {
                System.out.println("Pasirinkite veiksmą:");
                System.out.println("1. Peržiūrėti knygų sąrašą");
                System.out.println("2. Pridėti naują knygą");
                System.out.println("3. Ištrinti knygą");
                System.out.println("4. Grįžti");
                System.out.print("Įveskite pasirinkimą: ");
                int pasirinkimas = scanner.nextInt();
                scanner.nextLine(); // Nuskaityti likusią eilutę

                switch (pasirinkimas) {
                    case 1:
                        adminVeiksmai.perziuretiKnyguSarasa();
                        break;
                    case 2:
                        adminVeiksmai.pridetiKnyga();
                        break;
                    case 3:
                        adminVeiksmai.istrintiKnyga(scanner);
                        break;
                    case 4:
                        loggedIn = false;
                        break;
                    default:
                        System.out.println("Neteisingas pasirinkimas.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Neteisingas pasirinkimas. Prašome įvesti skaičių.");
                scanner.nextLine(); // Išvalyti įvesties srautą
            }
        }
    }
}
