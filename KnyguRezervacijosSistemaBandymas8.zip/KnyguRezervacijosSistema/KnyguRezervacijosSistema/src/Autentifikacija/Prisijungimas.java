package Autentifikacija;

import Knygos.KnyguRezervacija;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.sql.Connection;



public class Prisijungimas {
    private Connection connection;
    private Scanner scanner;

    public Prisijungimas(Connection connection, Scanner scanner) {
        this.connection = connection;
        this.scanner = scanner;
    }

    public void prisijungti() {
        try {
            System.out.println("Prisijungimas:");
            System.out.print("Vardas: ");
            String vardas = scanner.nextLine();
            System.out.print("Slaptažodis: ");
            String slaptazodis = scanner.nextLine();

            String sql = "SELECT * FROM naudotojai WHERE vardas = ? AND slaptazodis = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, vardas);
                preparedStatement.setString(2, slaptazodis);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        System.out.println("Sėkmingas prisijungimas!");
                        boolean loggedIn = true;
                        while (loggedIn) {
                            System.out.println("Pasirinkite veiksmą:");
                            System.out.println("1. Rezervuoti knygą");
                            System.out.println("2. Peržiūrėti rezervuotas knygas");
                            System.out.println("3. Grįžti");
                            System.out.print("Įveskite pasirinkimą (1, 2 arba 3): ");
                            int pasirinkimas = scanner.nextInt();
                            scanner.nextLine(); // Nuskaityti likusią eilutę

                            switch (pasirinkimas) {
                                case 1:
                                    rezervuotiKnygas(vardas);
                                    break;
                                case 2:
                                    perziuretiRezervuotasKnygas(vardas);
                                    break;
                                case 3:
                                    loggedIn = false;
                                    break;
                                default:
                                    System.out.println("Neteisingas pasirinkimas.");
                            }
                        }
                    } else {
                        System.out.println("Neteisingas vartotojo vardas arba slaptažodis.");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void perziuretiRezervuotasKnygas(String vartotojoVardas) {
        KnyguRezervacija knyguRezervacija = new KnyguRezervacija(connection, scanner);
        knyguRezervacija.perziuretiRezervuotasKnygas(vartotojoVardas);
    }

    private void rezervuotiKnygas(String vartotojoVardas) {
        KnyguRezervacija knyguRezervacija = new KnyguRezervacija(connection, scanner);
        knyguRezervacija.rezervuotiKnyga(vartotojoVardas);
    }
}
