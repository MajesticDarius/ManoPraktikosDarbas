package Administravimas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class AdministratoriausVeiksmai {
    private Connection connection;
    private Scanner scanner;

    public AdministratoriausVeiksmai(Connection connection, Scanner scanner) {
        this.connection = connection;
        this.scanner = scanner;
    }

    public void perziuretiKnyguSarasa() {
        try {
            String sql = "SELECT * FROM knygos";
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();

            System.out.println("Knygų sąrašas:");
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String pavadinimas = resultSet.getString("pavadinimas");
                String autorius = resultSet.getString("autorius");
                String zanras = resultSet.getString("zanras");
                System.out.println("ID: " + id + ", Pavadinimas: " + pavadinimas + ", Autorius: " + autorius + ", Žanras: " + zanras);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void pridetiKnyga() {
        try {
            System.out.print("Įveskite knygos pavadinimą: ");
            String pavadinimas = scanner.nextLine();
            System.out.print("Įveskite knygos autorių: ");
            String autorius = scanner.nextLine();
            System.out.print("Įveskite knygos žanrą: ");
            String zanras = scanner.nextLine();

            String sql = "INSERT INTO knygos (pavadinimas, autorius, zanras) VALUES (?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, pavadinimas);
            statement.setString(2, autorius);
            statement.setString(3, zanras);
            int affectedRows = statement.executeUpdate();
            if (affectedRows > 0) {
                System.out.println("Knyga pridėta sėkmingai.");
            } else {
                System.out.println("Nepavyko pridėti knygos.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void perziuretiNerezervuotasKnygas() {
        try {
            String sql = "SELECT * FROM knygos WHERE id NOT IN (SELECT knygos_id FROM rezervacijos)";
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();

            System.out.println("Nerezervuotos knygos:");
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String pavadinimas = resultSet.getString("pavadinimas");
                String autorius = resultSet.getString("autorius");
                String zanras = resultSet.getString("zanras");
                System.out.println("ID: " + id + ", Pavadinimas: " + pavadinimas + ", Autorius: " + autorius + ", Žanras: " + zanras);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void istrintiKnyga(Scanner scanner) {
        try {
            // Pirmiausia parodome nerezervuotas knygas
            perziuretiNerezervuotasKnygas();

            System.out.println("Įveskite knygos ID, kurią norite ištrinti, arba 0, jei norite atšaukti:");
            int knygosId = scanner.nextInt();
            scanner.nextLine(); // Nuskaityti likusią eilutę

            if (knygosId == 0) {
                System.out.println("Operacija atšaukta.");
                return; // Grįžti atgal į administratoriaus meniu
            }

            String sql = "DELETE FROM knygos WHERE id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, knygosId);
            int affectedRows = statement.executeUpdate();
            if (affectedRows > 0) {
                System.out.println("Knyga ištrinta sėkmingai.");
            } else {
                System.out.println("Nepavyko ištrinti knygos.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

