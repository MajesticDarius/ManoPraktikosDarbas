package Knygos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class KnyguRezervacija {
    private Connection connection;
    private Scanner scanner; // Deklaruojame scanner klasės lauką

    public KnyguRezervacija(Connection connection, Scanner scanner) {
        this.connection = connection;
        this.scanner = scanner; // Priskiriame perduotą scanner objektą klasės laukui
    }

    public void rezervuotiKnyga(String vartotojoVardas) {
        boolean reservationMenu = true;

        while (reservationMenu) {
            try {
                Scanner scanner = new Scanner(System.in);
                System.out.println("Prieinamos knygos:");
                perziuretiPrieinamasKnygas();

                System.out.println("Pasirinkite knygos ID, kurią norite rezervuoti (0 - grįžti):");
                int knygosId = scanner.nextInt();
                scanner.nextLine();

                if (knygosId == 0) {
                    reservationMenu = false;
                    break;
                }

                if (arKnygaPrieinama(knygosId)) {
                    if (!arKnygaRezervuota(knygosId)) {
                        rezervuotiKnyga(vartotojoVardas, knygosId);
                        System.out.println("Knyga sėkmingai rezervuota!");
                    } else {
                        System.out.println("Knyga jau rezervuota.");
                    }
                } else {
                    System.out.println("Pasirinkta knyga neprieinama.");
                }

                System.out.println("Ar norite tęsti rezervaciją? (taip / ne)");
                String atsakymas = scanner.nextLine();
                if (!atsakymas.equalsIgnoreCase("taip")) {
                    reservationMenu = false;
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private void perziuretiPrieinamasKnygas() throws SQLException {
        String sql = "SELECT id, pavadinimas FROM knygos WHERE prieinama = true AND id NOT IN (SELECT knygos_id FROM rezervacijos)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                int knygosId = resultSet.getInt("id");
                String pavadinimas = resultSet.getString("pavadinimas");
                System.out.println("ID: " + knygosId + ", Pavadinimas: " + pavadinimas);
            }
        }
    }

    private boolean arKnygaPrieinama(int knygosId) throws SQLException {
        String sql = "SELECT prieinama FROM knygos WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, knygosId);
            ResultSet resultSet = statement.executeQuery();
            return resultSet.next() && resultSet.getBoolean("prieinama");
        }
    }

    private boolean arKnygaRezervuota(int knygosId) throws SQLException {
        String sql = "SELECT COUNT(*) AS rezervuota FROM rezervacijos WHERE knygos_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, knygosId);
            ResultSet resultSet = statement.executeQuery();
            return resultSet.next() && resultSet.getInt("rezervuota") > 0;
        }
    }

    private void rezervuotiKnyga(String vartotojoVardas, int knygosId) throws SQLException {
        String sql = "INSERT INTO rezervacijos (knygos_id, vartotojo_vardas) VALUES (?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, knygosId);
            statement.setString(2, vartotojoVardas);
            statement.executeUpdate();
        }
    }

    public void grazintiKnyga(String vartotojoVardas) {
        try {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Pasirinkite knygos ID, kurią norite atiduoti (0 - grįžti):");
            int knygosId = scanner.nextInt();
            scanner.nextLine(); // Nuskaityti likusią eilutę

            if (knygosId == 0) {
                return; // Grįžti, jei vartotojas pasirinko grįžti
            }

            // Patikrinti, ar knyga yra rezervuota
            if (arKnygaRezervuota(knygosId)) {
                // Atid
                // Atiduoti knygą
                atiduotiKnyga(vartotojoVardas, knygosId);
                System.out.println("Knyga sėkmingai atiduota.");
            } else {
                System.out.println("Pasirinkta knyga nėra jūsų rezervacijose.");
            }
        } catch (SQLException e) {
            System.out.println("Įvyko duomenų bazės klaida: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void atiduotiKnyga(String vartotojoVardas, int knygosId) {
        try {
            String sql = "DELETE FROM rezervacijos WHERE vartotojo_vardas = ? AND knygos_id = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, vartotojoVardas);
                statement.setInt(2, knygosId);
                int affectedRows = statement.executeUpdate();

                if (affectedRows > 0) {
                    // Atnaujinti "knygos" lentelę, kad pažymėtų knygą kaip prieinamą
                    sql = "UPDATE knygos SET prieinama = true WHERE id = ?";
                    try (PreparedStatement updateStatement = connection.prepareStatement(sql)) {
                        updateStatement.setInt(1, knygosId);
                        updateStatement.executeUpdate();
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println("Įvyko duomenų bazės klaida: " + e.getMessage());
            e.printStackTrace();
        }

    }

    public void perziuretiRezervuotasKnygas(String vartotojoVardas) {
        try {
            String sql = "SELECT r.knygos_id, k.pavadinimas, k.autorius, k.zanras " +
                    "FROM rezervacijos r " +
                    "JOIN knygos k ON r.knygos_id = k.id " +
                    "WHERE r.vartotojo_vardas = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, vartotojoVardas);
            ResultSet resultSet = statement.executeQuery();

            if (!resultSet.next()) {
                System.out.println("Nėra rezervuotų knygų.");
            } else {
                System.out.println("Rezervuotos knygos:");
                do {
                    int knygosId = resultSet.getInt("knygos_id");
                    String pavadinimas = resultSet.getString("pavadinimas");
                    String autorius = resultSet.getString("autorius");
                    String zanras = resultSet.getString("zanras");
                    System.out.println("ID: " + knygosId + ", Pavadinimas: " + pavadinimas + ", Autorius: " + autorius + ", Žanras: " + zanras);
                } while (resultSet.next());

                System.out.println("Pasirinkite veiksmą:");
                System.out.println("1. Atiduoti knygas");
                System.out.println("2. Grįžti į pagrindinį meniu");
                System.out.print("Įveskite pasirinkimą: ");
                int pasirinkimas = scanner.nextInt();
                scanner.nextLine();

                switch (pasirinkimas) {
                    case 1:
                        atiduotiKnygas(vartotojoVardas);
                        break;
                    case 2:
                        return;
                    default:
                        System.out.println("Neteisingas pasirinkimas.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void atiduotiKnygas(String vartotojoVardas) {
        System.out.print("Įveskite atiduodamų knygų ID, atskirtų kableliais: ");
        String knyguIdsInput = scanner.nextLine();
        String[] knyguIds = knyguIdsInput.split(",");

        for (String knygosId : knyguIds) {
            try {
                String sql = "DELETE FROM rezervacijos WHERE vartotojo_vardas = ? AND knygos_id = ?";
                PreparedStatement statement = connection.prepareStatement(sql);
                statement.setString(1, vartotojoVardas);
                statement.setInt(2, Integer.parseInt(knygosId));
                int rowsAffected = statement.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Knyga su ID " + knygosId + " sėkmingai atiduota.");
                } else {
                    System.out.println("Knyga su ID " + knygosId + " nerasta arba nebuvo rezervuota.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }


}

