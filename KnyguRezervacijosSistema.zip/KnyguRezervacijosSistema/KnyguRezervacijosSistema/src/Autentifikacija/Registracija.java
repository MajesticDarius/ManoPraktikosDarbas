package Autentifikacija;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Registracija {
    private Connection connection;

    public Registracija(Connection connection) {
        this.connection = connection;
    }

    public void registruoti() {
        boolean registered = true;

        while (registered) {
            try {
                Scanner scanner = new Scanner(System.in);
                System.out.println("Registracija:");
                System.out.print("Vardas: ");
                String vardas = scanner.nextLine();

                String slaptazodis;
                String slaptazodisPatvirtinimas;
                do {
                    System.out.print("Slaptažodis: ");
                    slaptazodis = scanner.nextLine();
                    System.out.print("Pakartokite slaptažodį: ");
                    slaptazodisPatvirtinimas = scanner.nextLine();

                    if (!slaptazodis.equals(slaptazodisPatvirtinimas)) {
                        System.out.println("Slaptažodžiai nesutampa, bandykite dar kartą.");
                    }
                } while (!slaptazodis.equals(slaptazodisPatvirtinimas));

                System.out.print("El. paštas: ");
                String elPastas = scanner.nextLine();

                String sql = "INSERT INTO naudotojai (vardas, slaptazodis, el_pastas) VALUES (?, ?, ?)";
                try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                    preparedStatement.setString(1, vardas);
                    preparedStatement.setString(2, slaptazodis);
                    preparedStatement.setString(3, elPastas);

                    int affectedRows = preparedStatement.executeUpdate();
                    if (affectedRows > 0) {
                        System.out.println("Naujas vartotojas sėkmingai įrašytas į duomenų bazę.");

                        registered = false;

                        return;
                    } else {
                        System.out.println("Nepavyko įrašyti naujo vartotojo į duomenų bazę.");
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
