package DuomenuBaze;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DuomenuBaze {
    private static final String URL = "jdbc:mysql://localhost:3306/knygu_rezervacijos_sistema";
    private static final String VARTOTOJO_VARDAS = "root";
    private static final String SLAPTAZODIS = "";

    public static Connection prisijungti() throws SQLException {
        return DriverManager.getConnection(URL, VARTOTOJO_VARDAS, SLAPTAZODIS);
    }
}
